# not quite sure how to lay this all out yet
# i think login should be it's own file
# basically just take a user login or make a new one
# and return the id to main

import urllib.parse
import urllib.request
import json
import sqlite3
import os.path

# need to import a list of usernames and passwords

class login_system:
    def __init__(self):
        pass


    def register(self, input_name, input_pass): 
        self.new_name = input_name # modifying to take input in GUI
        self.new_pass = input_pass
        
        # copy pasted from other func so still testing
        self.fields = ["UserName", "UserPass"]
        self.values = [self.new_name, self.new_pass]
        try:
            with sqlite3.connect("MusicDB.db") as conn:
                print(f"Opened SQLite database with version {sqlite3.sqlite_version} successfully.")
                cursor = conn.cursor()
                # need to check if the value already exists first
                result = cursor.execute(f"""SELECT * FROM users
                                        WHERE {self.fields[0]}=?""",(self.values[0],)).fetchone()
                    
                if result: # if a thing already exists
                    print("value already exists")
                    
                else: # if a thing doesn't exist
                    cursor.execute(f"""INSERT INTO users ({self.fields[0]}, {self.fields[1]})
                                    VALUES ('{self.values[0]}', '{self.values[1]}')""")
                    print("added data successfully") # succes message for testing
                    conn.commit()

        except sqlite3.OperationalError as e:
            print("Failed to open database:", e)

        self.fields = []
        self.values = [] # clear arrays just in case
                
        
    def login(self, input_name, input_pass): # this needs to return a positive/negative and some kind of ID/login token
        print("login is case sensitive")
        self.input_name = input_name #editing this for cross file use
        self.input_pass = input_pass
        try: # this section could be done at the top of the class but is only actually necessary here to check
            with sqlite3.connect("MusicDB.db") as conn:
                print(f"Opened SQLite database with version {sqlite3.sqlite_version} successfully.")
                cursor = conn.cursor()
                # check for values and assign a local list
                cursor = conn.cursor()
                cursor.execute('SELECT UserID, UserName, UserPass FROM users')
                rows = cursor.fetchall()

                self.IDs = []
                self.usernames = []
                self.passwords = []

                for row in rows:
                    print(row[0], row[1], row[2])
                    self.IDs.append(row[0])
                    self.usernames.append(row[1])
                    self.passwords.append(row[2])

        except sqlite3.OperationalError as e:
            print("Failed to open database:", e)

        success = False
        for i in range(len(self.usernames)):
            if self.input_name == self.usernames[i] and self.input_pass == self.passwords[i]: # self is for cross file use
                print("login recognised")
                success = True
                return (self.IDs[i]) # return version 1
                break
                # this still needs to return the user id and specify it as the id to be used for the current session
        if not success:
            print("username or password not recognised")
